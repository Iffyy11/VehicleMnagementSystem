package groupproject3040;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class UserDashBoard extends JFrame {

    public UserDashBoard() {
        String userType = SessionManager.getUserType();
        String username = SessionManager.getUsername();

        // Session check
        if (userType == null || username == null) {
            JOptionPane.showMessageDialog(this, "Session expired. Please login again.");
            new Login().setVisible(true);
            dispose();
            return;
        }

        setTitle("Vehicle Management System - User Dashboard");
        setSize(1100, 650);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Left Panel (for User info)
        JPanel leftPanel = new JPanel();
        leftPanel.setPreferredSize(new Dimension(350, 650));
        leftPanel.setBackground(new Color(0, 102, 204));
        leftPanel.setLayout(new BoxLayout(leftPanel, BoxLayout.Y_AXIS));

        JLabel welcomeLabel = new JLabel("Welcome " + username + "!", JLabel.CENTER);
        welcomeLabel.setFont(new Font("Serif", Font.BOLD, 22));
        welcomeLabel.setForeground(Color.WHITE);
        welcomeLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel iconLabel = new JLabel(new ImageIcon("icons/user.png"));
        iconLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Logout Button
        JButton logoutButton = createStyledButton("Logout", "icons/logout.png");
        logoutButton.addActionListener(e -> {
            SessionManager.clearSession();
            new Login().setVisible(true); // Return to Login screen
            dispose();
        });

        // Exit Button
        JButton exitButton = createStyledButton("Exit", "icons/exit.png");
        exitButton.addActionListener(e -> System.exit(0)); // Exit the application

        leftPanel.add(Box.createVerticalStrut(50));
        leftPanel.add(welcomeLabel);
        leftPanel.add(Box.createVerticalStrut(10));
        leftPanel.add(iconLabel);
        leftPanel.add(Box.createVerticalGlue());
        leftPanel.add(logoutButton);
        leftPanel.add(exitButton);

        // Right Panel (for User's Options)
        JPanel rightPanel = new JPanel();
        rightPanel.setBackground(Color.WHITE);
        rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.Y_AXIS));

        // Add Vehicle Button
        JButton addVehicleButton = createStyledButton("Add Vehicle", "icons/vehicles.png");
        addVehicleButton.addActionListener(e -> {
            new VehicleManagement().setVisible(true);
            dispose(); // Close the User Dashboard
        });

        // Make Payment Button
        JButton makePaymentButton = createStyledButton("Make Payment", "icons/categories.png");
        makePaymentButton.addActionListener(e -> {
            new Payment().setVisible(true);
            dispose(); // Close the User Dashboard
        });

        // View Transactions Button
        JButton viewTransactionsButton = createStyledButton("View Transactions", "icons/transaction.png");
        viewTransactionsButton.addActionListener(e -> {
            new ViewTransactions().setVisible(true);
            dispose(); // Close the User Dashboard
        });

        // Book Vehicle Button (New Feature)
        JButton bookVehicleButton = createStyledButton("Book Vehicle", "icons/bookVehicle.png");
        bookVehicleButton.addActionListener(e -> {
            new BookingPage().setVisible(true); // Open Booking page
            dispose(); // Close the User Dashboard
        });

        // Contact Page Button (New Feature)
        JButton contactPageButton = createStyledButton("Contact Us", "icons/contact.png");
        contactPageButton.addActionListener(e -> {
            new ContactPage().setVisible(true); // Open Contact Us page
            dispose(); // Close the User Dashboard
        });

        // Set button size and add them to the right panel
        Dimension buttonSize = new Dimension(250, 50);
        for (JButton button : new JButton[]{addVehicleButton, makePaymentButton, viewTransactionsButton, bookVehicleButton, contactPageButton}) {
            button.setMaximumSize(buttonSize);
            rightPanel.add(Box.createVerticalStrut(10));
            rightPanel.add(button);
        }

        add(leftPanel, BorderLayout.WEST);
        add(rightPanel, BorderLayout.CENTER);
    }

    private JButton createStyledButton(String text, String iconPath) {
        JButton button = new JButton(text);
        button.setFont(new Font("Serif", Font.BOLD, 16));
        button.setForeground(Color.WHITE);
        button.setBackground(new Color(0, 102, 204));
        button.setBorderPainted(false);
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));

        if (iconPath != null) {
            button.setIcon(new ImageIcon(iconPath));
        }

        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(new Color(0, 120, 230)); // Hover effect
            }

            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(new Color(0, 102, 204)); // Reset effect
            }
        });

        return button;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            SessionManager.setUserType("user");
            SessionManager.setUsername("testUser");
            new UserDashBoard().setVisible(true);
        });
    }
}
