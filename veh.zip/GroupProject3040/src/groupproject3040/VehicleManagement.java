package groupproject3040;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;

public class VehicleManagement extends JFrame {
    private JTextField idField, makeField, modelField, yearField, categoryField, colorField, unitsField;
    private JButton addButton, returnButton;
    private String userType;

    public VehicleManagement() {
        setTitle("Vehicle Management System");
        setSize(450, 400);
        setLayout(new GridLayout(9, 2, 10, 10)); // Better spacing and structure

        // Input Fields
        add(new JLabel("Vehicle ID:"));
        idField = new JTextField();
        add(idField);

        add(new JLabel("Make:"));
        makeField = new JTextField();
        add(makeField);

        add(new JLabel("Model:"));
        modelField = new JTextField();
        add(modelField);

        add(new JLabel("Year:"));
        yearField = new JTextField();
        add(yearField);

        add(new JLabel("Category:"));
        categoryField = new JTextField();
        add(categoryField);

        add(new JLabel("Color:"));
        colorField = new JTextField();
        add(colorField);

        add(new JLabel("Available Units:"));
        unitsField = new JTextField();
        add(unitsField);

        // Buttons
        addButton = new JButton("Add Vehicle");
        returnButton = new JButton("Return to Dashboard");

        add(addButton);
        add(returnButton);

        addButton.addActionListener(e -> VehicleManagementToDatabase());

        returnButton.addActionListener(e -> {
            dispose();
            
            new AdministratorDashBoard().setVisible(true); // Opens the dashboard
        });

        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null); // Centers the window on the screen
        setVisible(true);
    }

    private void VehicleManagementToDatabase() {
        // Validating inputs first
        int id = validateIntegerInput(idField.getText(), "Vehicle ID");
        int year = validateIntegerInput(yearField.getText(), "Year");
        int units = validateIntegerInput(unitsField.getText(), "Available Units");

        if (id == -1 || year == -1 || units == -1) return; // Exit if validation failed

        String make = makeField.getText().trim();
        String model = modelField.getText().trim();
        String category = categoryField.getText().trim();
        String color = colorField.getText().trim();

        if (make.isEmpty() || model.isEmpty() || category.isEmpty() || color.isEmpty()) {
            JOptionPane.showMessageDialog(this, "All fields must be filled in.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // If validation passed, proceed to insert the data into the database
        try (Connection conn = ConnectorDb.connect()) {
            if (conn != null) {
                String sql = "INSERT INTO vehicle_info (ID, make, model, year, category, color, units) VALUES (?, ?, ?, ?, ?, ?, ?)";
                try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                    stmt.setInt(1, id);
                    stmt.setString(2, make);
                    stmt.setString(3, model);
                    stmt.setInt(4, year);
                    stmt.setString(5, category);
                    stmt.setString(6, color);
                    stmt.setInt(7, units);

                    stmt.executeUpdate();
                    JOptionPane.showMessageDialog(this, "Vehicle Added Successfully!");
                    clearFields(); // Clear the fields after successful insertion
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(this, "Error executing SQL query: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
                    ex.printStackTrace();
                }
            } else {
                JOptionPane.showMessageDialog(this, "Failed to connect to the database.", "Connection Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database connection error: " + ex.getMessage(), "Connection Error", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    }

    private int validateIntegerInput(String input, String fieldName) {
        try {
            return Integer.parseInt(input.trim());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, fieldName + " must be a valid integer.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return -1; // Indicate invalid input
        }
    }

    private void clearFields() {
        idField.setText("");
        makeField.setText("");
        modelField.setText("");
        yearField.setText("");
        categoryField.setText("");
        colorField.setText("");
        unitsField.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(VehicleManagement::new);
    }
}
