package groupproject3040;

import javax.swing.*;
import java.awt.*;

public class ContactPage extends JFrame {

    public ContactPage() {
        setTitle("Contact Us");
        setSize(600, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Content Panel
        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));

        // Title Label
        JLabel titleLabel = new JLabel("Contact Us", JLabel.CENTER);
        titleLabel.setFont(new Font("Serif", Font.BOLD, 24));
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Contact Info Labels
        JLabel phoneLabel = new JLabel("Phone: +123 456 789");
        phoneLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel emailLabel = new JLabel("Email: support@vehiclesystem.com");
        emailLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel addressLabel = new JLabel("Address: 123 Vehicle Street, City, Country");
        addressLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Adding components to content panel
        contentPanel.add(titleLabel);
        contentPanel.add(Box.createVerticalStrut(20));
        contentPanel.add(phoneLabel);
        contentPanel.add(Box.createVerticalStrut(10));
        contentPanel.add(emailLabel);
        contentPanel.add(Box.createVerticalStrut(10));
        contentPanel.add(addressLabel);

        // Close Button
        JButton closeButton = new JButton("Close");
        closeButton.setFont(new Font("Serif", Font.BOLD, 16));
        closeButton.addActionListener(e -> dispose()); // Close the contact page

        // Add components to the frame
        add(contentPanel, BorderLayout.CENTER);
        add(closeButton, BorderLayout.SOUTH);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ContactPage().setVisible(true));
    }
}
