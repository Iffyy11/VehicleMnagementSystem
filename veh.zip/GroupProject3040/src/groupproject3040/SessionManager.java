package groupproject3040;

public class SessionManager {
    private static String userType;
    private static String username;

    public static void setUserType(String type) {
        userType = type;
    }

    public static String getUserType() {
        return userType;
    }

    public static void setUsername(String name) {
        username = name;
    }

    public static String getUsername() {
        return username;
    }

    public static void clearSession() {
        userType = null;
        username = null;
    }
}
