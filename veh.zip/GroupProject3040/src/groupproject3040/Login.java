package groupproject3040;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class Login extends JFrame {

    private JTextField usernameField;
    private JPasswordField passwordField;

    public Login() {
        setTitle("Login");
        setSize(400, 250);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setLayout(new GridLayout(3, 2, 10, 10));

        // Labels and fields
        JLabel usernameLabel = new JLabel("Username:");
        usernameField = new JTextField();

        JLabel passwordLabel = new JLabel("Password:");
        passwordField = new JPasswordField();

        JButton loginButton = new JButton("Login");
        JButton signupButton = new JButton("Sign Up");

        add(usernameLabel);
        add(usernameField);
        add(passwordLabel);
        add(passwordField);
        add(loginButton);
        add(signupButton);

        // Listeners
        loginButton.addActionListener(e -> loginUser());

        signupButton.addActionListener(e -> {
            new SignUp().setVisible(true);
            dispose();
        });

        setVisible(true);
    }

    private void loginUser() {
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword()).trim();

        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Both fields are required!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String sql = "SELECT userType FROM users WHERE username = ? AND password = ?";
        try (Connection connection = ConnectorDb.connect();
             PreparedStatement stmt = connection.prepareStatement(sql)) {

            stmt.setString(1, username);
            stmt.setString(2, password);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                String userType = rs.getString("userType");

                // Debugging: Check the userType from the database
                System.out.println("User Type: " + userType); // Debugging line

                // Store session info
                SessionManager.setUserType(userType);
                SessionManager.setUsername(username);

                // Route based on user role
                if ("admin".equalsIgnoreCase(userType)) {
                    new AdministratorDashBoard().setVisible(true);  // Admin dashboard
                } else if ("user".equalsIgnoreCase(userType)) {
                    new UserDashBoard().setVisible(true);  // User dashboard
                } else {
                    JOptionPane.showMessageDialog(this, "Unknown user role.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                dispose(); // Close the login screen after successful login

            } else {
                JOptionPane.showMessageDialog(this, "Invalid username or password.", "Login Failed", JOptionPane.ERROR_MESSAGE);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Database error", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(Login::new);  // Run the login screen
    }
}
