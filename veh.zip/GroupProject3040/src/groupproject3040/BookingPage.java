package groupproject3040;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class BookingPage extends JFrame {

    private String userType;

    public BookingPage() {
        setTitle("Booking Page");
        setSize(500, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(6, 2, 10, 10));

        // Components
        JLabel vehicleLabel = new JLabel("Select Vehicle:");
        String[] vehicles = {"Huracan_EVI", "McLaren_720s", "McLaren_Senna", "Ferrari_SF90_Spider"};
        JComboBox<String> vehicleDropdown = new JComboBox<>(vehicles);

        JLabel daysLabel = new JLabel("Number of Days:");
        JTextField daysField = new JTextField();

        JLabel totalCostLabel = new JLabel("Total Cost:");
        JLabel costValueLabel = new JLabel("RM0.00");

        JButton bookButton = new JButton("Book Now");
        JButton cancelButton = new JButton("Cancel");
        JButton returnButton = new JButton("Return to Dashboard");

        // Button actions
        bookButton.addActionListener(e -> {
            try {
                int days = Integer.parseInt(daysField.getText());
                if (days <= 0) throw new NumberFormatException();

                String selectedVehicle = (String) vehicleDropdown.getSelectedItem();
                double pricePerDay = getVehiclePrice(selectedVehicle);
                double total = days * pricePerDay;
                costValueLabel.setText("RM" + total);

                JOptionPane.showMessageDialog(this, "Booking Successful for " + selectedVehicle + "!");
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Please enter a valid number of days.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        cancelButton.addActionListener((ActionEvent e) -> dispose());

        returnButton.addActionListener((ActionEvent e) -> {
            new AdministratorDashBoard().setVisible(true);  // Make the Admin Dashboard visible
            dispose(); // Close the BookingPage
        });

        // Layout
        add(vehicleLabel);
        add(vehicleDropdown);
        add(daysLabel);
        add(daysField);
        add(totalCostLabel);
        add(costValueLabel);
        add(bookButton);
        add(cancelButton);
        add(returnButton);
    }

    private double getVehiclePrice(String vehicle) {
        switch (vehicle) {
            case "Huracan_EVI": return 4000;
            case "McLaren_720s": return 2952;
            case "McLaren_Senna": return 3102;
            case "Ferrari_SF90_Spider": return 3873;
            default: return 0;
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new BookingPage().setVisible(true));
    }
}
