package groupproject3040;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

public class Payment extends JFrame {
    private JTextField cardNumberField, expiryDateField, cvvField, amountField;
    private String userType;

    public Payment() {
        setTitle("Payment Page");
        setSize(600, 500);  // Increased size to accommodate the new fields
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new GridLayout(7, 2)); // Increased grid rows to fit the new fields
        setLocationRelativeTo(null);

        // UI components
        JLabel transactionIdLabel = new JLabel("Transaction ID (Auto-generated):");
        JTextField transactionIdField = new JTextField();
        transactionIdField.setEditable(false);  // Make Transaction ID field non-editable
        transactionIdField.setText(generateTransactionID());  // Automatically generate Transaction ID

        JLabel cardNumberLabel = new JLabel("Card Number:");
        cardNumberField = new JTextField();

        JLabel expiryDateLabel = new JLabel("Expiry Date (MM/YY):");
        expiryDateField = new JTextField();

        JLabel cvvLabel = new JLabel("CVV:");
        cvvField = new JTextField();

        JLabel amountLabel = new JLabel("Amount (Calculated):");
        amountField = new JTextField();
        amountField.setEditable(false);  // Make Amount field non-editable

        JButton submitButton = new JButton("Submit Payment");
        JButton cancelButton = new JButton("Cancel");
        JButton returnButton = new JButton("Return to Dashboard");

        // Add action listeners
        submitButton.addActionListener(e -> {
            String cardNumber = cardNumberField.getText().trim();
            String expiryDate = expiryDateField.getText().trim();
            String cvv = cvvField.getText().trim();

            if (cardNumber.isEmpty() || expiryDate.isEmpty() || cvv.isEmpty()) {
                JOptionPane.showMessageDialog(this, "All fields are required.", "Input Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Calculate amount (For example, calculate it based on card details or booking options)
            double amount = calculateAmount(); // Replace with your actual calculation logic
            amountField.setText("RM" + amount);

            if (insertPaymentIntoDatabase(transactionIdField.getText(), cardNumber, expiryDate, cvv, amount)) {
                JOptionPane.showMessageDialog(this, "Payment Submitted!");
                clearFields();
            } else {
                JOptionPane.showMessageDialog(this, "Error processing payment.");
            }
        });

        cancelButton.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, "Payment Cancelled.");
            dispose();
        });

        returnButton.addActionListener(e -> {
            new AdministratorDashBoard().setVisible(true);  // Make the Admin Dashboard visible
            dispose(); // Close the PaymentPage
        });

        // Add components to frame
        add(transactionIdLabel); add(transactionIdField);
        add(cardNumberLabel); add(cardNumberField);
        add(expiryDateLabel); add(expiryDateField);
        add(cvvLabel); add(cvvField);
        add(amountLabel); add(amountField);
        add(submitButton); add(cancelButton);
        add(returnButton);  // Add the return button to the layout

        setVisible(true);
    }

    private boolean insertPaymentIntoDatabase(String transactionId, String cardNumber, String expiryDate, String cvv, double amount) {
        String sql = "INSERT INTO payment_db (TransactionID, CardNumber, ExpiryDate, CVV, Amount) VALUES (?, ?, ?, ?, ?)";

        try (Connection connection = ConnectorDb.connect();
             PreparedStatement stmt = connection.prepareStatement(sql)) {

            stmt.setString(1, transactionId);  // Set Transaction ID
            stmt.setInt(2, Integer.parseInt(cardNumber));  // Set Card Number
            stmt.setString(3, expiryDate);  // Set Expiry Date
            stmt.setString(4, cvv);  // Set CVV
            stmt.setDouble(5, amount);  // Set Amount

            int rows = stmt.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    private String generateTransactionID() {
        // Logic to generate a unique transaction ID, e.g., from the database or custom method
        // In this case, assuming auto-generation in DB, or you can generate based on time or random number
        return "TX" + System.currentTimeMillis();  // Example format: TX1609459200000
    }

    private double calculateAmount() {
        // Example logic to calculate the payment amount
        // Replace this with your actual calculation logic based on booking or card details
        return 100.0; // Example amount
    }

    private void clearFields() {
        cardNumberField.setText("");
        expiryDateField.setText("");
        cvvField.setText("");
        amountField.setText(""); // Clear the Amount field as well
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Payment());
    }
}
