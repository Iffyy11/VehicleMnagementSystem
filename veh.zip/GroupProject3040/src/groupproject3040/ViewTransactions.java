package groupproject3040;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.sql.*;

public class ViewTransactions extends JFrame {

    private JTable transactionsTable;

    public ViewTransactions() {
        setTitle("View Transactions");
        setSize(800, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Table Setup
        String[] columnNames = {"Transaction ID", "Username", "Card Number", "Expiry Date", "CVV", "Amount"};
        DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0);
        transactionsTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(transactionsTable);
        add(scrollPane, BorderLayout.CENTER);

        // Return Button Panel
        JPanel buttonPanel = new JPanel();
        JButton returnButton = new JButton("Return to Dashboard");

        returnButton.addActionListener((ActionEvent e) -> {
            String userType = SessionManager.getUserType();

            if ("admin".equalsIgnoreCase(userType)) {
                new AdministratorDashBoard().setVisible(true);
            } else if ("user".equalsIgnoreCase(userType)) {
                new UserDashBoard().setVisible(true);
            } else {
                JOptionPane.showMessageDialog(this, "Session expired or unknown user type. Please login again.");
                new Login().setVisible(true);
            }

            dispose();
        });

        buttonPanel.add(returnButton);
        add(buttonPanel, BorderLayout.SOUTH);

        // Load transactions based on role
        loadTransactionsData();
    }

    private void loadTransactionsData() {
        String userType = SessionManager.getUserType();
        String username = SessionManager.getUsername();

        if (userType == null || username == null) {
            JOptionPane.showMessageDialog(this, "Session expired. Please log in again.");
            new Login().setVisible(true);
            dispose();
            return;
        }

        String sql = "admin".equalsIgnoreCase(userType)
                ? "SELECT * FROM payment_db"
                : "SELECT * FROM payment_db WHERE username = ?";

        try (Connection connection = ConnectorDb.connect();
             PreparedStatement stmt = connection.prepareStatement(sql)) {

            if (!"admin".equalsIgnoreCase(userType)) {
                stmt.setString(1, username);
            }

            ResultSet rs = stmt.executeQuery();
            DefaultTableModel model = (DefaultTableModel) transactionsTable.getModel();
            model.setRowCount(0); // Clear existing rows

            while (rs.next()) {
                Object[] row = {
                        rs.getInt("TransactionID"),
                        rs.getString("username"),
                        rs.getString("CardNumber"),
                        rs.getString("ExpiryDate"),
                        rs.getString("CVV"),
                        rs.getDouble("Amount")
                };
                model.addRow(row);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading transaction data.", "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        // TESTING ONLY
        SessionManager.setUserType("user"); // Try "admin" or "user"
        SessionManager.setUsername("testuser");
        SwingUtilities.invokeLater(ViewTransactions::new);
    }
}
